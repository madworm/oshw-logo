
Use 'scale.pl' to resize / h-mirror any .emp file created with KiCad's
Bitmap2Component tool. Image data is h-mirrored automatically once 
either the bottom-copper or bottom-silkscreen layer is selected.


scale.pl old.emp new.emp <layer> 5.0mm

or 

scale.pl old.emp new.emp <layer> 0.5in


Replace <layer> with the KiCad layer you need. Run 'scale.pl'
to get more information.

KiCad layers:
-------------

top copper     : 15
top silk       : 21
bottom copper  :  0
bottom silk    : 20


Now start kicad/pcbnew, go into the library/footprint editor
("open module editor", it's the icon looking like a DIP chip
with a pencil) and click on the "import module" icon, select
the .emp file of your choice and click OK.

To place the logo onto the board just click on the "insert module
into current board icon".

Place the logo where you need it. If the size is still not correct,
repeat at the beginning. Press 'F' to move it to a bottom layer
(either silkscreen or copper).

If the logo doesn't show up on your gerber files, your version
of kicad still suffers from bug #792399.

